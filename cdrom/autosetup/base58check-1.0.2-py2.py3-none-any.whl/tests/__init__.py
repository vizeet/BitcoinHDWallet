import sys
from os.path import join, dirname


sys.path.insert(0, join(dirname(__file__), '..'))
